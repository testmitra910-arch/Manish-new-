package com.example.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

enum class UserRole {
    @Json(name = "main_admin") MAIN_ADMIN,
    @Json(name = "admin") ADMIN,
    @Json(name = "student") STUDENT
}

enum class TestStatus {
    @Json(name = "draft") DRAFT,
    @Json(name = "published") PUBLISHED,
    @Json(name = "unpublished") UNPUBLISHED
}

enum class AttemptStatus {
    @Json(name = "in_progress") IN_PROGRESS,
    @Json(name = "completed") COMPLETED,
    @Json(name = "submitted") SUBMITTED,
    @Json(name = "time_expired") TIME_EXPIRED
}

@JsonClass(generateAdapter = true)
data class Profile(
    val id: String,
    @Json(name = "auth_id") val authId: String? = null,
    val name: String,
    @Json(name = "mobile_number") val mobileNumber: String,
    val role: String, // "main_admin", "admin", "student"
    @Json(name = "is_active") val isActive: Boolean = true,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "updated_at") val updatedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class ExamType(
    val id: String, // "navodaya", "nmms", "gyan_setu", "gyan_sadhana", "tet_1"
    val name: String,
    val description: String? = null,
    @Json(name = "is_active") val isActive: Boolean = true
)

@JsonClass(generateAdapter = true)
data class AdminInfo(
    val id: String,
    @Json(name = "profile_id") val profileId: String,
    @Json(name = "assigned_exam_type_id") val assignedExamTypeId: String? = null,
    @Json(name = "is_main_admin") val isMainAdmin: Boolean = false,
    @Json(name = "is_active") val isActive: Boolean = true,
    @Json(name = "created_by") val createdBy: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class StudentInfo(
    val id: String,
    @Json(name = "profile_id") val profileId: String,
    @Json(name = "exam_type_id") val examTypeId: String,
    @Json(name = "is_active") val isActive: Boolean = true,
    @Json(name = "created_by") val createdBy: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class Test(
    val id: String,
    @Json(name = "exam_type_id") val examTypeId: String,
    val name: String,
    val description: String? = null,
    @Json(name = "duration_minutes") val durationMinutes: Int = 30,
    @Json(name = "passing_marks") val passingMarks: Int = 33,
    val status: String = "published", // "draft", "published", "unpublished"
    @Json(name = "created_by") val createdBy: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class Question(
    val id: String,
    @Json(name = "test_id") val testId: String,
    @Json(name = "question_text") val questionText: String,
    @Json(name = "option_a") val optionA: String,
    @Json(name = "option_b") val optionB: String,
    @Json(name = "option_c") val optionC: String,
    @Json(name = "option_d") val optionD: String,
    @Json(name = "correct_answer") val correctAnswer: String, // "A", "B", "C", "D"
    val marks: Int = 1,
    @Json(name = "question_order") val questionOrder: Int = 1
)

@JsonClass(generateAdapter = true)
data class NotificationItem(
    val id: String,
    @Json(name = "exam_type_id") val examTypeId: String,
    val title: String,
    val message: String,
    @Json(name = "is_active") val isActive: Boolean = true,
    @Json(name = "created_by") val createdBy: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class TestAttempt(
    val id: String,
    @Json(name = "test_id") val testId: String,
    @Json(name = "student_id") val studentId: String,
    @Json(name = "started_at") val startedAt: String? = null,
    @Json(name = "submitted_at") val submittedAt: String? = null,
    @Json(name = "time_taken_seconds") val timeTakenSeconds: Int = 0,
    val score: Int = 0,
    @Json(name = "total_marks") val totalMarks: Int = 0,
    val status: String = "in_progress" // "in_progress", "completed", "submitted", "time_expired"
)

@JsonClass(generateAdapter = true)
data class TestAnswer(
    val id: String,
    @Json(name = "attempt_id") val attemptId: String,
    @Json(name = "question_id") val questionId: String,
    @Json(name = "selected_answer") val selectedAnswer: String?, // "A", "B", "C", "D", "UNANSWERED"
    @Json(name = "is_correct") val isCorrect: Boolean = false,
    @Json(name = "marks_obtained") val marksObtained: Int = 0
)

@JsonClass(generateAdapter = true)
data class ActiveSession(
    val id: String,
    @Json(name = "user_id") val userId: String,
    @Json(name = "session_id") val sessionId: String,
    @Json(name = "device_id") val deviceId: String,
    @Json(name = "device_name") val deviceName: String? = null,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "last_active_at") val lastActiveAt: String? = null,
    @Json(name = "is_active") val isActive: Boolean = true
)

data class TestResultSummary(
    val attempt: TestAttempt,
    val testName: String,
    val studentName: String,
    val totalQuestions: Int,
    val correctCount: Int,
    val wrongCount: Int,
    val unansweredCount: Int,
    val score: Int,
    val totalMarks: Int,
    val percentage: Float,
    val timeTakenSeconds: Int,
    val answers: List<TestAnswerDetail> = emptyList()
)

data class TestAnswerDetail(
    val question: Question,
    val selectedAnswer: String?,
    val correctAnswer: String,
    val isCorrect: Boolean
)
