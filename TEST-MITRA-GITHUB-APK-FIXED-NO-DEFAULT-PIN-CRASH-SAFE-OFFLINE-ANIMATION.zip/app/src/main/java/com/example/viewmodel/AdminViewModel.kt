package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Repository
import com.example.model.AdminInfo
import com.example.model.ExamType
import com.example.model.NotificationItem
import com.example.model.Profile
import com.example.model.Question
import com.example.model.StudentInfo
import com.example.model.Test
import com.example.model.TestResultSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class AdminViewModel(application: Application) : AndroidViewModel(application) {

    val repository = Repository(application)

    private val _examTypes = MutableStateFlow<List<ExamType>>(emptyList())
    val examTypes: StateFlow<List<ExamType>> = _examTypes.asStateFlow()

    private val _students = MutableStateFlow<List<Pair<Profile, StudentInfo>>>(emptyList())
    val students: StateFlow<List<Pair<Profile, StudentInfo>>> = _students.asStateFlow()

    private val _admins = MutableStateFlow<List<Pair<Profile, AdminInfo>>>(emptyList())
    val admins: StateFlow<List<Pair<Profile, AdminInfo>>> = _admins.asStateFlow()

    private val _tests = MutableStateFlow<List<Test>>(emptyList())
    val tests: StateFlow<List<Test>> = _tests.asStateFlow()

    private val _questions = MutableStateFlow<List<Question>>(emptyList())
    val questions: StateFlow<List<Question>> = _questions.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationItem>>(emptyList())
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    private val _results = MutableStateFlow<List<TestResultSummary>>(emptyList())
    val results: StateFlow<List<TestResultSummary>> = _results.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() { _message.value = null }

    fun loadExamTypes() {
        viewModelScope.launch {
            _examTypes.value = repository.getExamTypes()
        }
    }

    fun loadStudents(examTypeId: String? = null) {
        viewModelScope.launch {
            _isLoading.value = true
            _students.value = repository.getStudents(examTypeId)
            _isLoading.value = false
        }
    }

    fun loadAdmins() {
        viewModelScope.launch {
            _isLoading.value = true
            _admins.value = repository.getAdmins()
            _isLoading.value = false
        }
    }

    fun loadTests(examTypeId: String? = null) {
        viewModelScope.launch {
            _isLoading.value = true
            _tests.value = repository.getTests(examTypeId)
            _isLoading.value = false
        }
    }

    fun loadQuestions(testId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _questions.value = repository.getQuestions(testId)
            _isLoading.value = false
        }
    }

    fun loadNotifications(examTypeId: String? = null) {
        viewModelScope.launch {
            _isLoading.value = true
            _notifications.value = repository.getNotifications(examTypeId)
            _isLoading.value = false
        }
    }

    fun loadResults() {
        viewModelScope.launch {
            _isLoading.value = true
            _results.value = repository.getAllResults()
            _isLoading.value = false
        }
    }

    fun addStudent(name: String, mobile: String, pass: String, examTypeId: String, adminProfileId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.createStudentAccount(name, mobile, pass, examTypeId, adminProfileId)
            res.onSuccess {
                _message.value = "વિદ્યાર્થી સફળતાપૂર્વક ઉમેરાયો."
                loadStudents(examTypeId)
            }.onFailure {
                _message.value = it.message ?: "વિદ્યાર્થી ઉમેરવામાં ભૂલ આવી."
            }
            _isLoading.value = false
        }
    }

    fun addAdmin(name: String, mobile: String, pass: String, examTypeId: String?) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.createAdminAccount(name, mobile, pass, examTypeId)
            res.onSuccess {
                _message.value = "એડમિન સફળતાપૂર્વક ઉમેરાયો."
                loadAdmins()
            }.onFailure {
                _message.value = it.message ?: "એડમિન ઉમેરવામાં ભૂલ આવી."
            }
            _isLoading.value = false
        }
    }

    fun toggleProfileActive(profileId: String, currentActive: Boolean, examTypeId: String? = null) {
        viewModelScope.launch {
            repository.updateProfileStatus(profileId, !currentActive)
            _message.value = "Status અપડેટ થયું."
            loadStudents(examTypeId)
            loadAdmins()
        }
    }

    fun deleteProfile(profileId: String, examTypeId: String? = null) {
        viewModelScope.launch {
            repository.deleteProfile(profileId)
            _message.value = "એકાઉન્ટ કાઢી નાખવામાં આવ્યું."
            loadStudents(examTypeId)
            loadAdmins()
        }
    }

    fun addTest(name: String, desc: String, examTypeId: String, duration: Int, passingMarks: Int, creatorProfileId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val test = Test(
                id = UUID.randomUUID().toString(),
                examTypeId = examTypeId,
                name = name.trim(),
                description = desc.trim(),
                durationMinutes = duration,
                passingMarks = passingMarks,
                status = "published",
                createdBy = creatorProfileId
            )
            repository.createTest(test)
            _message.value = "ટેસ્ટ સફળતાપૂર્વક ઉમેરાઈ."
            loadTests(examTypeId)
            _isLoading.value = false
        }
    }

    fun toggleTestStatus(testId: String, currentStatus: String, examTypeId: String?) {
        viewModelScope.launch {
            val nextStatus = if (currentStatus == "published") "unpublished" else "published"
            repository.updateTestStatus(testId, nextStatus)
            _message.value = "ટેસ્ટ Status બદલાયું."
            loadTests(examTypeId)
        }
    }

    fun deleteTest(testId: String, examTypeId: String?) {
        viewModelScope.launch {
            repository.deleteTest(testId)
            _message.value = "ટેસ્ટ ડીલીટ થઈ ગઈ."
            loadTests(examTypeId)
        }
    }

    fun addQuestion(
        testId: String,
        qText: String,
        optA: String,
        optB: String,
        optC: String,
        optD: String,
        correctAns: String,
        marks: Int,
        order: Int
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val question = Question(
                id = UUID.randomUUID().toString(),
                testId = testId,
                questionText = qText.trim(),
                optionA = optA.trim(),
                optionB = optB.trim(),
                optionC = optC.trim(),
                optionD = optD.trim(),
                correctAnswer = correctAns.uppercase(),
                marks = marks,
                questionOrder = order
            )
            repository.createQuestion(question)
            _message.value = "પ્રશ્ન ઉમેરાયો."
            loadQuestions(testId)
            _isLoading.value = false
        }
    }

    fun deleteQuestion(questionId: String, testId: String) {
        viewModelScope.launch {
            repository.deleteQuestion(questionId)
            _message.value = "પ્રશ્ન ડીલીટ થયો."
            loadQuestions(testId)
        }
    }

    fun addNotification(title: String, message: String, examTypeId: String, creatorProfileId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val item = NotificationItem(
                id = UUID.randomUUID().toString(),
                examTypeId = examTypeId,
                title = title.trim(),
                message = message.trim(),
                isActive = true,
                createdBy = creatorProfileId
            )
            repository.createNotification(item)
            _message.value = "સૂચના પ્રસિદ્ધ થઈ."
            loadNotifications(examTypeId)
            _isLoading.value = false
        }
    }

    fun deleteNotification(notificationId: String, examTypeId: String?) {
        viewModelScope.launch {
            repository.deleteNotification(notificationId)
            _message.value = "સૂચના કાઢી નાખવામાં આવી."
            loadNotifications(examTypeId)
        }
    }
}
