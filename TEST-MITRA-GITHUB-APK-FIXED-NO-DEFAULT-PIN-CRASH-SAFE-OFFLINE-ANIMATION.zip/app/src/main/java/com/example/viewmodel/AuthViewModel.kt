package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Repository
import com.example.data.SupabaseConfig
import com.example.data.local.LocalProfileEntity
import com.example.model.Profile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AuthState {
    object Initial : AuthState()
    object Loading : AuthState()
    data class Authenticated(val profile: LocalProfileEntity) : AuthState()
    object Unauthenticated : AuthState()
    data class Error(val message: String) : AuthState()
}

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    val repository = Repository(application)

    private val _authState = MutableStateFlow<AuthState>(AuthState.Initial)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _currentProfile = MutableStateFlow<LocalProfileEntity?>(null)
    val currentProfile: StateFlow<LocalProfileEntity?> = _currentProfile.asStateFlow()

    private val _isConfigured = MutableStateFlow(SupabaseConfig.isConfigured(application))
    val isConfigured: StateFlow<Boolean> = _isConfigured.asStateFlow()

    init {
        checkSession()
    }

    fun checkSession() {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val local = repository.getLocalProfile()
            if (local != null) {
                val isSessionValid = repository.verifyActiveSession(local.id)
                if (isSessionValid) {
                    _currentProfile.value = local
                    _authState.value = AuthState.Authenticated(local)
                } else {
                    repository.logout()
                    _currentProfile.value = null
                    _authState.value = AuthState.Error("તમારું એકાઉન્ટ બીજા ઉપકરણ (Device) માં લોગિન થયું છે.")
                }
            } else {
                _currentProfile.value = null
                _authState.value = AuthState.Unauthenticated
            }
            } catch (e: Exception) {
                // Never let a local DB/session error crash the app during startup.
                _currentProfile.value = null
                _authState.value = AuthState.Unauthenticated
            }
        }
    }

    fun login(mobile: String, pass: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            val result = repository.login(mobile, pass)
            result.onSuccess {
                checkSession()
            }.onFailure { e ->
                _authState.value = AuthState.Error(e.message ?: "લોગિન નિષ્ફળ ગયું.")
            }
        }
    }

    fun setupFirstMainAdmin(name: String, mobile: String, pass: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            val result = repository.setupFirstMainAdmin(name, mobile, pass)
            result.onSuccess {
                login(mobile, pass)
            }.onFailure { e ->
                _authState.value = AuthState.Error(e.message ?: "Main Admin બનાવવામાં ભૂલ આવી.")
            }
        }
    }

    fun saveSupabaseConfig(url: String, key: String) {
        SupabaseConfig.saveConfig(getApplication(), url, key)
        _isConfigured.value = SupabaseConfig.isConfigured(getApplication())
        checkSession()
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
            _currentProfile.value = null
            _authState.value = AuthState.Unauthenticated
        }
    }
}
